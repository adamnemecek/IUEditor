from django.contrib import admin
from galleryApp.models import *
# Register your models here.

admin.site.register(Picture)
