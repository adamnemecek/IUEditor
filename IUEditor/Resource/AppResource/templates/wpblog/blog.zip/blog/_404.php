<!DOCTYPE html>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>IUTemplate - Blog</title>
        <meta property='og:title' content='IUTemplate - Blog' />
        <meta name='twitter:title' content='IUTemplate - Blog'>
        <meta itemprop='name' content='IUTemplate - Blog'>
        <meta name='keywords' content='IUEditor, Template, Wordpress, Blog'>
        <meta name='author' content='IUEditor'>
        <meta property='og:site_name' content='IUEditor' />
        <meta name='twitter:creator' content='IUEditor'>
        <link rel='icon' type='image/x-icon' href='resource/image/wp_favicon.ico'>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='http://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/reset.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/iu.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/_404.css">

        <script src='http://code.jquery.com/jquery-1.10.2.js'></script>
        <script src='http://code.jquery.com/ui/1.9.2/jquery-ui.js'></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/jquery.event.swipe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuframe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iu.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iucarousel.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuevent.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuinit.js"></script>
        <script src="http://maps.googleapis.com/maps/api/js?v=3.exp"></script>
        <script src="http://f.vimeocdn.com/js/froogaloop2.min.js"></script>

        <!--[if lt IE 9]>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/jquery.backgroundSize.js"></script>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/respond.min.js"></script>
         <![endif]-->
        <style id=default>
  ._404 {background-size:cover; border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; background-attachment:fixed; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/2560x1600.jpg'); background-color:rgb(255,255,255); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; background-position:center center; }  
  .Box4 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:200px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/warning.png'); height:200px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:100px; }  
  .WPMenu1 > div > ul {text-align:right; }  
  .WPMenu1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:0px; font-family:Arial; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenu1 > div > ul > li {display:inline-block; padding:0 20px; line-height:60px; position:relative; }  
  .Boxcopy7 {text-align:center; border-left-width:0px; display:inherit; border-left-color:rgb(0,0,0); font-family:Helvetica; border-bottom-width:0px; width:560px; border-top-color:rgb(0,0,0); font-size:12px; background-repeat:no-repeat; opacity:0.50; line-height:2.00; filter:alpha(opacity=50); border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:220px; }  
  .Box28 {border-left-width:0px; display:none; border-bottom-color:rgb(0,0,0); width:100.00%; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; background-color:rgb(245,245,245); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:60px; }  
  .Section9 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:340px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSiteDescription3 {color:rgb(169,169,169); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:11px; border-bottom-color:rgb(0,0,0); margin-top:24px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:14px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPSidebar4 > .WPWidget {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; float:right; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy20 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:80px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box13 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:100.00%; overflow:visible; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSidebar4 > .WPWidget > .WPWidgetTitle {text-align:right; position:relative; display:inherit; border-left-color:rgb(0,0,0); font-family:'Roboto', sans-serif; width:180px; font-size:14px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-left-width:0px; line-height:1.50; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Header {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; overflow:visible; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSidebar4 {margin-top:50px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:60.00%; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-top-color:rgb(0,0,0); background-repeat:no-repeat; float:right; border-left-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; margin-right:40px; }  
  .Boxcopy21 {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .text404 {text-align:center; border-left-width:0px; display:inherit; border-left-color:rgb(0,0,0); font-family:'Roboto', sans-serif; width:750px; font-size:14px; border-top-color:rgb(0,0,0); color:rgb(0,0,0); background-repeat:no-repeat; line-height:2.00; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:330px; }  
  .Section5 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(213,213,213); width:100.00%; border-bottom-color:rgb(213,213,213); margin-top:0px; border-top-color:rgb(213,213,213); background-repeat:no-repeat; border-bottom-width:1px; height:500px; background-color:rgb(254,255,255); border-right-width:0px; border-right-color:rgb(213,213,213); border-top-width:1px; border-style:solid; }  
  .WPMenucopy1 > div > ul {text-align:center; }  
  .WPMenucopy1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:14px; border-bottom-color:rgb(0,0,0); background-repeat:no-repeat; font-family:Arial; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenucopy1 > div > ul > li {display:inline-block; padding:0 10px; line-height:60px; position:relative; }  
  .Boxcopy6 {text-align:center; border-left-width:0px; border-bottom-color:rgb(0,0,0); display:inherit; font-family:'Montserrat', sans-serif; width:700px; border-left-color:rgb(0,0,0); border-top-color:rgb(0,0,0); font-size:30px; background-repeat:no-repeat; line-height:1.30; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:130px; }  
  .Box27 {left:0px; background-position:center center; border-left-width:0px; display:none; border-left-color:rgb(0,0,0); width:50px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/menu_white.png'); height:60px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:0px; }  
  .pageContent {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSiteTitle3 {color:rgb(254,255,255); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:18px; border-bottom-color:rgb(0,0,0); margin-top:17px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:20px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPSidebar4 > .WPWidget > ul {text-align:right; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:10px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; opacity:0.50; display:inherit; border-left-width:0px; width:180px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Box12 {left:0px; top:0px; border-left-width:0px; position:fixed; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:61px; overflow:visible; z-index:10; background-color:rgb(33,33,33); border-right-color:rgb(0,0,0); border-right-width:0px; border-top-width:0px; }  
  .Boxcopy19 {text-align:left; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:50px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; opacity:0.50; display:inherit; border-left-width:0px; width:30.00%; margin-left:40px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Sectioncopy6 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Background1 {border-right-color:rgb(0,0,0); display:inherit; border-top-color:rgb(0,0,0); border-top-width:0px; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; border-right-width:0px; border-left-width:0px; }  
</style>
<style type="text/css" media ='screen and (min-width:768px) and (max-width:959px)' id='style768'>  .Box13 {width:768px; }  
  .WPSidebar4 > .WPWidget > .WPWidgetTitle {width:228px; }  
  .WPSidebar4 {width:684px; margin-right:42px; }  
  .Boxcopy21 {width:768px; }  
  .WPMenucopy1 {font-size:12px; }  
  .WPSidebar4 > .WPWidget > ul {width:228px; }  
  .Boxcopy19 {margin-left:0px; width:100.00%; text-align:center; }  
</style>
<style type="text/css" media ='screen and (max-width:767px)' id='style320'>  .Box4 {width:140px; background-size:cover; height:140px; }  
  .WPMenu1 {display:none; }  
  .Boxcopy7 {top:140px; width:240px; font-size:11px; }  
  .Box28 {display:inherit; }  
  .Section9 {display:none; height:280px; }  
  .WPSiteDescription3 {display:none; }  
  .Box13 {width:100.00%; }  
  .WPSidebar4 {display:none; margin-right:-0px; }  
  .Boxcopy21 {width:320px; }  
  .text404 {top:270px; width:90.00%; font-size:12px; }  
  .WPMenucopy1 {font-family:'Roboto', sans-serif; color:rgb(0,0,0); width:100.00%; }  
  .Boxcopy6 {top:80px; width:300px; font-size:18px; }  
  .Box27 {display:inherit; }  
  .WPSiteTitle3 {margin-left:54px; }  
  .Boxcopy19 {width:100.00%; margin-left:0px; }  
  .Sectioncopy6 {height:180px; }  
</style>

    </head>
    <body>
<div id="_404" class='IUPage IUSheet IUBox  _404' >
  <div id="Header" class='IUHeader IUBox  Header'>
    <div id="Box12" class='IUBox  Box12' horizontalCenter='1'>
      <div id="Box13" class='IUBox  Box13' horizontalCenter='1'>
       <div id="WPSiteTitle3" class='WPSiteTitle IUBox  WPSiteTitle3' ><h1><a href="<?php echo home_url(); ?>"><?bloginfo()?></a></h1></div>
       <div id="WPSiteDescription3" class='WPSiteDescription IUBox  WPSiteDescription3' ><?bloginfo('description')?></div>
       <div id="WPMenu1" class='WPMenu IUBox  WPMenu1' ><? wp_nav_menu() ?></div>
        <div id="Box27" class='IUBox  Box27'></div>
        <div id="Box28" class='IUBox  Box28'>
         <div id="WPMenucopy1" class='WPMenu IUBox  WPMenucopy1' ><? wp_nav_menu() ?></div>
        </div>
      </div>
    </div>
  </div>
  <div id="pageContent" class='IUPageContent IUBox  pageContent'>
    <div id="Section9" class='IUSection IUBox  Section9'>
      <div id="Boxcopy6" class='IUBox  Boxcopy6' horizontalCenter='1'>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>  
      </div>
      <div id="Boxcopy7" class='IUBox  Boxcopy7' horizontalCenter='1'>
        <p>Curabitur varius, justo vel lobortis porta, purus nibh tincidunt dui, nec egestas nisl felis ut ex.<br>Donec ut feugiat felis. Donec aliquet vulputate rutrum.</p>  
      </div>
    </div>
    <div id="Section5" class='IUSection IUBox  Section5'>
      <div id="Box4" class='IUBox  Box4' horizontalCenter='1'></div>
      <div id="text404" class='IUBox  text404' horizontalCenter='1'>
        <p>Sorry, but the page you are looking for has not been found.<br>Try checking the URL for errors, then hit the refresh button.</p>  
      </div>
    </div>
    <div id="Sectioncopy6" class='IUSection IUBox  Sectioncopy6'>
      <div id="Boxcopy21" class='IUBox  Boxcopy21' horizontalCenter='1'>
        <div id="Boxcopy19" class='IUBox  Boxcopy19'>
          <p>Copyright (C) Blog Owner all rights reserved<br>Wordpress Theme powered by IUEditor</p>  
        </div>
       <div id="WPSidebar4" class='WPSidebar IUBox  WPSidebar4' ><?php dynamic_sidebar( 'IUWidgets' ); ?>  <div id="WPWidget4" class='WPWidget IUBox  WPWidget4'>
           <div id="WPWidgetTitle4" class='WPWidgetTitle IUBox  WPWidgetTitle4'></div>
           <div id="WPWidgetBody4" class='WPWidgetBody IUBox  WPWidgetBody4'></div>
         </div>
       </div>
        <div id="Boxcopy20" class='IUBox  Boxcopy20'></div>
      </div>
    </div>
  </div>
</div>

    </body>
</HTML>


