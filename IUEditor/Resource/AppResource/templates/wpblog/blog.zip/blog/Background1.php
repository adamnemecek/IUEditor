<!DOCTYPE html>
<HTML>
    <head>
        <meta charset="utf-8">
        <!--METADATA_Insert-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--WEBFONT_Insert-->
        <!--CSS_Insert-->
        <!--JAVASCRIPT_Insert-->
        <!--[if lt IE 9]>
         <script type="text/javascript" src="resource/js/ie/jquery.backgroundSize.js"></script>
         <script type="text/javascript" src="resource/js/ie/respond.min.js"></script>
         <![endif]-->
        <!--CSS_Replacement-->
    </head>
    <body>
<!--HTML_Replacement-->
    </body>
</HTML>


