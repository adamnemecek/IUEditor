<!DOCTYPE html>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>IUTemplate - Blog</title>
        <meta property='og:title' content='IUTemplate - Blog' />
        <meta name='twitter:title' content='IUTemplate - Blog'>
        <meta itemprop='name' content='IUTemplate - Blog'>
        <meta name='keywords' content='IUEditor, Template, Wordpress, Blog'>
        <meta name='author' content='IUEditor'>
        <meta property='og:site_name' content='IUEditor' />
        <meta name='twitter:creator' content='IUEditor'>
        <link rel='icon' type='image/x-icon' href='resource/image/wp_favicon.ico'>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='http://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/reset.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/iu.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/page.css">

        <script src='http://code.jquery.com/jquery-1.10.2.js'></script>
        <script src='http://code.jquery.com/ui/1.9.2/jquery-ui.js'></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/jquery.event.swipe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuframe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iu.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iucarousel.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuevent.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuinit.js"></script>
        <script src="http://maps.googleapis.com/maps/api/js?v=3.exp"></script>
        <script src="http://f.vimeocdn.com/js/froogaloop2.min.js"></script>

        <!--[if lt IE 9]>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/jquery.backgroundSize.js"></script>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/respond.min.js"></script>
         <![endif]-->
        <style id=default>
  .page {background-size:cover; border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; background-attachment:fixed; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/2560x1600.jpg'); background-color:rgb(255,255,255); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; background-position:center center; }  
  .Sectioncopy2 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(213,213,213); width:100.00%; border-bottom-color:rgb(213,213,213); margin-top:0px; border-top-color:rgb(213,213,213); background-repeat:no-repeat; border-bottom-width:1px; background-color:rgb(254,255,255); border-right-width:0px; border-right-color:rgb(213,213,213); border-top-width:1px; border-style:solid; }  
  .WPMenu1 > div > ul {text-align:right; }  
  .WPMenu1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:0px; font-family:Arial; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenu1 > div > ul > li {display:inline-block; padding:0 20px; line-height:60px; position:relative; }  
  .WPArticlecopy1 {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); width:100.00%; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy8 {text-align:center; border-left-width:0px; border-bottom-color:rgb(0,0,0); display:inherit; font-family:'Montserrat', sans-serif; width:700px; border-left-color:rgb(0,0,0); border-top-color:rgb(0,0,0); font-size:30px; background-repeat:no-repeat; line-height:1.30; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:130px; }  
  .Boxcopy23 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:80px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box28 {border-left-width:0px; display:none; border-bottom-color:rgb(0,0,0); width:100.00%; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; background-color:rgb(245,245,245); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:60px; }  
  .Sectioncopy1 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:340px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSidebar3 > .WPWidget > .WPWidgetTitle {text-align:right; position:relative; display:inherit; border-left-color:rgb(0,0,0); font-family:'Roboto', sans-serif; width:180px; font-size:14px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-left-width:0px; line-height:1.50; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSiteDescription3 {color:rgb(169,169,169); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:11px; border-bottom-color:rgb(0,0,0); margin-top:24px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:14px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Boxcopy24 {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box13 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:100.00%; overflow:visible; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy12 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:100px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Header {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; overflow:visible; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPArticleTitlecopy1 {text-align:center; position:relative; display:inherit; border-left-width:0px; font-family:'Roboto', sans-serif; width:100.00%; font-size:21px; border-top-color:rgb(0,0,0); color:rgb(119,121,175); background-repeat:no-repeat; line-height:2.00; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy13 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:960px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPMenucopy1 > div > ul {text-align:center; }  
  .WPMenucopy1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:14px; border-bottom-color:rgb(0,0,0); background-repeat:no-repeat; font-family:Arial; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenucopy1 > div > ul > li {display:inline-block; padding:0 10px; line-height:60px; position:relative; }  
  .Boxcopy9 {text-align:center; border-left-width:0px; display:inherit; border-left-color:rgb(0,0,0); font-family:Helvetica; border-bottom-width:0px; width:560px; border-top-color:rgb(0,0,0); font-size:12px; background-repeat:no-repeat; opacity:0.50; line-height:2.00; filter:alpha(opacity=50); border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:220px; }  
  .Boxcopy10 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:100.00%; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:0px; }  
  .WPSidebar3 > .WPWidget {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; float:right; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSidebar3 > .WPWidget > ul {text-align:right; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:10px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; opacity:0.50; display:inherit; border-left-width:0px; width:180px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .pageContent {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy22 {text-align:left; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:50px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; opacity:0.50; display:inherit; border-left-width:0px; width:30.00%; margin-left:40px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPSiteTitle3 {color:rgb(254,255,255); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:18px; border-bottom-color:rgb(0,0,0); margin-top:17px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:20px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPSidebar3 {margin-top:50px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:60.00%; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-top-color:rgb(0,0,0); background-repeat:no-repeat; float:right; border-left-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; margin-right:40px; }  
  .Sectioncopy7 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box12 {left:0px; top:0px; border-left-width:0px; position:fixed; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:61px; overflow:visible; z-index:10; background-color:rgb(33,33,33); border-right-color:rgb(0,0,0); border-right-width:0px; border-top-width:0px; }  
  .Box27 {left:0px; background-position:center center; border-left-width:0px; display:none; border-left-color:rgb(0,0,0); width:50px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/menu_white.png'); height:60px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:0px; }  
  .Boxcopy11 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:120px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:40px; height:1px; background-color:rgb(192,192,192); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPArticleBodycopy1 {left:0px; border-left-width:0px; position:relative; display:inherit; text-align:left; font-family:'Roboto', sans-serif; width:100.00%; font-size:13px; border-top-color:rgb(0,0,0); margin-top:40px; background-repeat:no-repeat; line-height:2.00; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPArticleListcopy1 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:800px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:100px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Background1 {border-right-color:rgb(0,0,0); display:inherit; border-top-color:rgb(0,0,0); border-top-width:0px; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; border-right-width:0px; border-left-width:0px; }  
</style>
<style type="text/css" media ='screen and (min-width:768px) and (max-width:959px)' id='style768'>  .WPSidebar3 > .WPWidget > .WPWidgetTitle {width:228px; }  
  .Boxcopy24 {width:768px; }  
  .Box13 {width:768px; }  
  .Boxcopy13 {width:768px; }  
  .WPMenucopy1 {font-size:12px; }  
  .Boxcopy10 {width:768px; }  
  .WPSidebar3 > .WPWidget > ul {width:228px; margin-top:9px; left:0px; }  
  .Boxcopy22 {margin-left:0px; width:100.00%; text-align:center; }  
  .WPSidebar3 {width:684px; margin-right:42px; }  
  .WPArticleListcopy1 {width:720px; }  
</style>
<style type="text/css" media ='screen and (max-width:767px)' id='style320'>  .WPMenu1 {display:none; }  
  .Box28 {display:inherit; }  
  .WPSiteDescription3 {display:none; }  
  .Boxcopy24 {width:320px; }  
  .Box13 {width:100.00%; }  
  .Boxcopy13 {width:100.00%; }  
  .WPMenucopy1 {font-family:'Roboto', sans-serif; color:rgb(0,0,0); width:100.00%; }  
  .Boxcopy10 {width:320px; }  
  .Boxcopy22 {margin-left:0px; width:100.00%; text-align:center; }  
  .WPSiteTitle3 {margin-left:54px; }  
  .WPSidebar3 {display:none; margin-right:-0px; }  
  .Sectioncopy7 {height:180px; }  
  .Box27 {display:inherit; }  
  .WPArticleListcopy1 {width:86.00%; }  
</style>

    </head>
    <body>
<div id="page" class='IUPage IUSheet IUBox  page' >
  <div id="Header" class='IUHeader IUBox  Header'>
    <div id="Box12" class='IUBox  Box12' horizontalCenter='1'>
      <div id="Box13" class='IUBox  Box13' horizontalCenter='1'>
       <div id="WPSiteTitle3" class='WPSiteTitle IUBox  WPSiteTitle3' ><h1><a href="<?php echo home_url(); ?>"><?bloginfo()?></a></h1></div>
       <div id="WPSiteDescription3" class='WPSiteDescription IUBox  WPSiteDescription3' ><?bloginfo('description')?></div>
       <div id="WPMenu1" class='WPMenu IUBox  WPMenu1' ><? wp_nav_menu() ?></div>
        <div id="Box27" class='IUBox  Box27'></div>
        <div id="Box28" class='IUBox  Box28'>
         <div id="WPMenucopy1" class='WPMenu IUBox  WPMenucopy1' ><? wp_nav_menu() ?></div>
        </div>
      </div>
    </div>
  </div>
  <div id="pageContent" class='IUPageContent IUBox  pageContent'>
    <div id="Sectioncopy1" class='IUSection IUBox  Sectioncopy1'>
      <div id="Boxcopy10" class='IUBox  Boxcopy10' horizontalCenter='1'>
        <div id="Boxcopy8" class='IUBox  Boxcopy8' horizontalCenter='1'>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>  
        </div>
        <div id="Boxcopy9" class='IUBox  Boxcopy9' horizontalCenter='1'>
          <p>Curabitur varius, justo vel lobortis porta, purus nibh tincidunt dui, nec egestas nisl felis ut ex.<br>Donec ut feugiat felis. Donec aliquet vulputate rutrum.</p>  
        </div>
      </div>
    </div>
    <div id="Sectioncopy2" class='IUSection IUBox  Sectioncopy2'>
      <div id="Boxcopy13" class='IUBox  Boxcopy13' horizontalCenter='1'>
       <div id="WPArticleListcopy1" class='WPArticleList IUBox  WPArticleListcopy1' horizontalCenter='1' ><? while ( have_posts() ) : the_post(); ?>  <div id="WPArticlecopy1" class='WPArticle IUBox  WPArticlecopy1'>
          <div id="WPArticleTitlecopy1" class='WPArticleTitle IUBox  WPArticleTitlecopy1' horizontalCenter='1' ><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
           <div id="Boxcopy11" class='IUBox  Boxcopy11' horizontalCenter='1'></div>
          <div id="WPArticleBodycopy1" class='WPArticleBody IUBox  WPArticleBodycopy1' ><?php the_content(); ?></div>
         </div>
       <? endwhile ?></div>
        <div id="Boxcopy12" class='IUBox  Boxcopy12'></div>
      </div>
    </div>
    <div id="Sectioncopy7" class='IUSection IUBox  Sectioncopy7'>
      <div id="Boxcopy24" class='IUBox  Boxcopy24' horizontalCenter='1'>
        <div id="Boxcopy22" class='IUBox  Boxcopy22'>
          <p>Copyright (C) Blog Owner all rights reserved<br>Wordpress Theme powered by IUEditor</p>  
        </div>
       <div id="WPSidebar3" class='WPSidebar IUBox  WPSidebar3' ><?php dynamic_sidebar( 'IUWidgets' ); ?>  <div id="WPWidget3" class='WPWidget IUBox  WPWidget3'>
           <div id="WPWidgetTitle3" class='WPWidgetTitle IUBox  WPWidgetTitle3'></div>
           <div id="WPWidgetBody3" class='WPWidgetBody IUBox  WPWidgetBody3'></div>
         </div>
       </div>
        <div id="Boxcopy23" class='IUBox  Boxcopy23'></div>
      </div>
    </div>
  </div>
</div>

    </body>
</HTML>


