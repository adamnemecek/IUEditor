from django.contrib import admin
from mainApp.models import *
# Register your models here.
# admin page
class PortfolioAdmin(admin.ModelAdmin):
    list_display=('title', 'url');
    
class ContactAdmin(admin.ModelAdmin):
    list_display=('name','email','subject');
    

admin.site.register(Portfolio, PortfolioAdmin)
admin.site.register(Contact, ContactAdmin)