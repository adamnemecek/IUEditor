from django.shortcuts import render
from mainApp.models import *
from django.shortcuts import redirect, render, render_to_response
from django import forms
from django.forms import ModelForm

class ContactForm(ModelForm):
    name = forms.CharField(required=True)
    email = forms.CharField(required=True)
    subject = forms.CharField(required=True)
    content = forms.CharField(required=True)
    
    class Meta:
        model = Contact

def index(request):

    if request.method == 'POST':
        contactForm = ContactForm(request.POST)
        if contactForm.is_valid():
            contactForm.save()
    
    portfolioObjects = Portfolio.objects.order_by('-id')
    return render(request, 'index.html', {'portfolio':portfolioObjects})


