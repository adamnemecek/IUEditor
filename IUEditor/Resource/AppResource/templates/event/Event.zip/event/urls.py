from django.conf.urls import patterns, include, url
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    url(r'^admin/', include(admin.site.urls)),
    # Examples:
    url(r'^$', 'mainApp.views.index'),
    url(r'^index$', 'mainApp.views.index'),
    url(r'^about$', 'mainApp.views.about'),
    url(r'^schedule$', 'mainApp.views.schedule'),
    url(r'^faq$', 'mainApp.views.faq'),
    url(r'^news$', 'mainApp.views.news'),
    url(r'^news/(\d+)$', 'mainApp.views.news'),
)


